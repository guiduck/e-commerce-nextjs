describe("AddProductForm E2E", () => {
  beforeEach(() => {
    cy.intercept("POST", "**/files/upload", {
      statusCode: 200,
      body: { location: "https://fake.img/url.png" },
    }).as("uploadImage");

    cy.intercept("POST", "**/products", {
      statusCode: 200,
      body: { id: 123, title: "Mock Product" },
    }).as("addProduct");

    cy.visit("/produtos");
  });

  it("submits with valid data", () => {
    // ✅ No need to click
    cy.get('input[name="title"]').type("Test Product");
    cy.get('input[name="price"]').type("19.99");
    cy.get('input[name="description"]').type("A test product");

    cy.get('select[aria-label="Categoria"]').select(1);

    cy.get('input[type="file"]').selectFile("cypress/fixtures/test-image.png", {
      force: true,
    });

    cy.contains("Salvar").click();

    cy.wait("@uploadImage");
    cy.wait("@addProduct");

    cy.contains("Produto criado com sucesso!").should("exist");
  });
});
