import { render, screen, fireEvent } from "@testing-library/react";
import FullScreenMenu from "@/components/FullScreenMenu";

jest.mock("next/navigation", () => ({
  usePathname: () => "/products",
}));

jest.mock("@/components/ui/theme-toggle", () => ({
  __esModule: true,
  default: () => <div data-testid="theme-toggle" />,
}));

describe("FullScreenMenu", () => {
  beforeEach(() => {
    global.fetch = jest.fn(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve({}),
      })
    ) as jest.Mock;

    delete (window as any).location;
    (window as any).location = { href: "", assign: jest.fn() };
  });

  it("opens and shows menu items", () => {
    render(<FullScreenMenu />);
    fireEvent.click(screen.getByRole("button", { name: "≡" }));

    expect(screen.getByText("Menu")).toBeInTheDocument();
    expect(screen.getByText("Locations")).toBeInTheDocument();
    expect(screen.getByText("Products")).toBeInTheDocument();
    expect(screen.getByText("Logout")).toBeInTheDocument();
  });

  it("calls logout on click", async () => {
    render(<FullScreenMenu />);
    fireEvent.click(screen.getByRole("button", { name: "≡" }));

    fireEvent.click(screen.getByText("Logout"));

    expect(global.fetch).toHaveBeenCalledWith("/api/auth/logout", {
      method: "POST",
    });
  });
});
