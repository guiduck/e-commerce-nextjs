import API from "@/lib/api";
import { createAPIError } from "@/lib/createAPIError";
import { Product } from "@/types/products";

export async function getProductById(id: number) {
  const response = await API<Product>({ url: `products/${id}`, method: "GET" });

  if (response.error || !response.data) {
    return createAPIError<Product>(
      "Produto não encontrado",
      response.status,
      response.debug
    );
  }

  return response;
}
