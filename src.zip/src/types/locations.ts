export type LocationsType = {
  latitude: number;
  longitude: number;
  label: string;
  activity: string;
};
